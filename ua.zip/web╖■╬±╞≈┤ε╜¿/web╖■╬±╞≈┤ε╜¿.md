## 一. IHS服务器搭建
UAT测试环境web服务器为双机负载，后面通过集群方式负载到两台was集群应用服务器。针对两台web服务器功能定位可分为两块：<br/>
- 前端h5静态资源服务器
- 后台接口转发<br/>

针对上述两点，分别进行配置说明<br/>
地址：10.20.161.51、10.20.161.52<br/>
用户名密码：root/srcb123

1. 行里提供web服务器默认使用root用户启停IHS服务，为保证系统稳定性和账户安全性，建议建立手机银行统一实例用户mbank，密码mbank。使用mbank来启停IHS服务。
2. 建立静态资源目录
	
		mkdir -p /home/mbank/IHS/html/mbank
3. 打开IHS安装目录<br/>
`cd /was/ibmHttpServer`
4. 打开IHS代理加载模块
		
		LoadModule proxy_module modules/mod_proxy.so
		LoadModule proxy_connect_module modules/mod_proxy_connect.so
		LoadModule proxy_http_module modules/mod_proxy_http.so
   基于IHS软负载配置，需要单独添加负载均衡模块
		
		LoadModule proxy_balancer_module modules/WebSphereCE/mod_proxy_balancer.so

5. 修改监听端口

		#Listen 12.34.56.78:80
		Listen 8088
6. 建立手机银行集群定义

		801 #<Proxy *>
		802 #    Order deny,allow
		803 #    Deny from all
		804 #    Allow from .example.com
		805 #</Proxy>
		806 <Proxy balancer://mbankcluster>
		807      BalancerMember http://10.20.158.137:9081 loadfactor=3
		808      BalancerMember http://10.20.158.167:9081 loadfactor=3
		809 </Proxy>


7.新建VirtualHost反向代理配置节点，并配置静态资源通过本地资源进行加载

		<VirtualHost *:8088>
	        #ServerName 10.20.158.116
	        DocumentRoot /was/ibmHttpServer
	        ErrorLog         apache_mbank_error.log
	        ProxyErrorOverride On
	        ProxyRequests On
	        ProxyPreserveHost On
	        LogLevel debug
	        <IfModule alias_module>
	        Alias /mbank/page/ "/home/yitong/IHS/html/mbank/mbank_srcb/page/"
	        <Directory "/home/yitong/IHS/html/mbank/mbank_srcb/page">	 
	                   <FilesMatch "\.(js|css|gif|png|PNG|jpe?g|JPE?G|html|tpl)$">
	                   </FilesMatch>
	        </Directory>
	        </IfModule>
	        #<IfModule alias_module>
	        #Alias /mbank/test/ "/home/yitong/IHS/html/mbank/mbank_srcb/test/"
	        #<Directory "/home/yitong/IHS/html/mbank/mbank_srcb/test">
	                   #<FilesMatch "\.(js|css|gif|png|PNG|jpe?g|JPE?G|html|tpl)#$">
	                   #</FilesMatch>
	        #</Directory>
	        #</IfModule>
	        <IfModule alias_module>
	        Alias /mbank/js/ "/home/yitong/IHS/html/mbank/mbank_srcb/js/"
	        <Directory "/home/yitong/IHS/html/mbank/mbank_srcb/js">
	                   <FilesMatch "\.js$">
	                   </FilesMatch>
	        </Directory>
			</IfModule>
	        <IfModule alias_module>
	        Alias /mbank/css/ "/home/yitong/IHS/html/mbank/mbank_srcb/css/"
	        <Directory "/home/yitong/IHS/html/mbank/mbank_srcb/css">
	                   <FilesMatch "\.(css|gif|png|jpe?g|JPE?G|ttf|eot|svg|woff)$">
	                   </FilesMatch>
	        </Directory>
	        </IfModule>
	        <IfModule alias_module>
	        Alias /mbank/data/ "/home/yitong/IHS/html/mbank/mbank_srcb/data/"
	        <Directory "/home/yitong/IHS/html/mbank/mbank_srcb/data">
	                   <FilesMatch "\.(js|JSON|json)$">
	                   </FilesMatch>
	        </Directory>
	        </IfModule>
	        ProxyPassMatch /css/ !
	        ProxyPassMatch /*.JSON !
	        ProxyPassMatch /*.css !
	        ProxyPassMatch /*.js !
	        ProxyPassMatch /*.html$ !
	        ProxyPass       /mbank   balancer://mbankcluster/mbank
	        ProxyPassReverse /mbank  balancer://mbankcluster/mbank
	        ErrorDocument 404 /error/404/index.html
		</VirtualHost>

7. 针对通过后台流式加载图片资源需要在web服务器缓存配置以减少应用服务器压力和提高网速，该部分后面补充
8. 保存httpd.conf配置文件并退出编辑模式
9. VirtualHost中配置404页面待统一绘制。目前使用一张静态页面代替，待补充
10. 执行`bin/apachectl restart`重启应用实例
11. 另外一台web服务器仿照上述操作进行即可
