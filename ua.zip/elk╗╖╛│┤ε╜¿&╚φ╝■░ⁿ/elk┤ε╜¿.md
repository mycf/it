## jdk环境搭建
服务器10.20.158.176
用户名密码 root/srcb123
目前uat服务器上自带openjdk1.7版本，可针对该版本进行卸载<br/>
先查看 `rpm -qa | grep java`<br/>
执行卸载：`rpm -e --nodeps XXX`<br/>


切换至mbank用户
1. 上传soft.tar.gz软件包
2. 解压软件包 `tar -zxvf soft.tar.gz`
3. 进入当前用户目录 `cd ~`
4. 设置环境变量
	`vi ~/.bash_profile `
	修改文件内容如下：
	    PATH=$PATH:$HOME/bin
    	JAVA_HOME=/home/mbank/soft/jdk1.8.0_91
    	PATH=$JAVA_HOME/bin:$PATH:$HOME/bin
    	export JAVA_HOME
    	export PATH
5. 执行 `. ~/.bash_profile`应用当前环境变量
6. 执行java -version查看jdk环境是否安全成功


## 单机redis搭建（服务于logstash）
1. 依赖jdk中软件包
2. 修改redis.conf中`bind 10.20.158.176`
3. 启动redis单节点实例`bin/redis-server ./redis.conf &`
4. 确认redis实例是否启动成功 `ps -ef|grep redis`
5. 由于测试环境，考虑测试压力不大，暂时redis仅在logstash服务器上部署单一节点，后期如果存在压力过大，可酌情进行扩展


## logstash 部署
1. 依赖jdk中软件包
2. 进入logstash目录`cd /home/mbank/soft/logstash-5.2.1/`
3. 上传配置好的logstash.conf & startLogstash.sh配置文件至该目录（软件包中已经包含）
4. vi进入logstash.conf修改内容如下：
		input {
		    redis {
		        host => "10.20.158.120"
		        port => 6379
		        type => "redis-input"
		        data_type => "list"
		        key => "logstash"
		    }
		}
		
		filter {
		     mutate {
		       convert => { "TOTAL_TIME" => "integer" }
		    }
		
		}
		
		output {
		    elasticsearch {
		        hosts => ["10.20.158.125:9200"]
		    }
		}
5. 执行`./startLogstash.sh` 如果该文件没有执行权限，请`chmod +x startLogstash.sh`；注意，由于logstash依赖elasticsearch的输出，故此，需要先起elasticsearch服务后，再起logstash，详见elasticsearch。启动完成显示如下：
![](imgs/3.png)

## elasticsearch部署
1. 依赖jdk中软件包
2. 进入elasticsearch目录 `cd /home/mbank/soft/elasticsearch-5.2.1`
3. 由于elastic依赖内核环境需要针对内核环境做以下修改
	- 修改配置$PWD/config/elasticsearch.yml
		新增如下参数
		`bootstrap.system_call_filter: false`注意，参数false之前有空格

	- 检查防火墙策略，防火墙是否关闭，没有关闭需要执行关闭 永久关闭&临时关闭
		关闭防火墙的方法为：
			永久性生效
			开启：chkconfig iptables on 
			关闭：chkconfig iptables off
			即时生效，重启后失效
			开启：service iptables start
			关闭：service iptables stop 
		补充：
			a. 防火墙还需要关闭ipv6的防火墙：
			chkconfig ip6tables off
			并且可以通过如下命令查看状态：
			chkconfig --list iptables
			b. selinux状态可以通过以下命令查看：
			sestatus

	- 修改配置$PWD/config/elasticsearch.yml文件
		取消此参数的注释，并修改ip地址为服务器的ip地址
		`network.host: 10.20.158.176`*注意参数值前有空格*

	- 修改配置$PWD/config/elasticsearch.yml文件-修改日志存储路径，并将/data目录赋权限给当前mbank用户`chown /data mbank`
		
		`path.data: /data`

	- 修改/etc/security/limits.conf
		添加如下代码
			* soft nofile 65536
			* hard nofile 65536
		**退出ssh会话，从新登陆才能生效。**
	- 修改/etc/security/limits.d/90-nproc.conf文件
		修改如下代码，将1024改成2048
			修改前
			*          soft    nproc     1024
			修改后
			*          soft    nproc     2048
		**退出ssh会话，从新登陆才能生效。**
	- 修改/etc/sysctl.conf文件
		添加如下代码，存在就修改，没有就新增
		`vm.max_map_count=262144`
		**使用sysctl –p /etc/sysctl.conf，使配置生效**
 
4. 启动elasticsearch服务
		cd /home/elastic/soft/elasticsearch-5.2.1/bin
		./elasticsearch -d (后台运行参数)
5. 外部浏览器访问[http://10.20.158.176:9200/](http://10.20.158.176:9200/)，出现以下图片证明配置成功
![](imgs/2.png)