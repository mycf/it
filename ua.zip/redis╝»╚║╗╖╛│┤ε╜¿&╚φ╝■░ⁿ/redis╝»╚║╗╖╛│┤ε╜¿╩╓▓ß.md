## 一.redis集群缓存服务器环境搭建
uat环境redis服务器<br/>
地址：10.20.158.145,10.20.158.149,10.20.158.168<br/>
密码：root/srcb123<br/>
目前三台服务器含有gcc环境，可直接下载redis源码包进行gcc编译后安装，鉴于SIT环境已存在编译程序包，故此下面部署形式不含有gcc编码安装部分，如果需要可参考SIT redis源码包编译安装部分。<br/>

1. 分别在三台服务器建立手机银行统一用户密码<br/>
`groupadd mbank`<br/>
`useradd mbank -g mbank`<br/>
修改mbank密码为mbank

2. 使用root用户针对三台服务器分别上传
3. 编译后程序包和redis-*.gem包（ruby gem环境）
`gem install redis-3.2.1.gem` 
安装完成结果如下

		[root@h158145 soft]# gem install redis-3.2.1.gem 
		Successfully installed redis-3.2.1
		1 gem installed
		Installing ri documentation for redis-3.2.1...
		Installing RDoc documentation for redis-3.2.1...


3. 切换mbank用户，并进入mbank目录<br/>
`su - mbnak`<br/>
`cd ~`<br/>
4. 在mbank用户目录下新建soft目录
`mkdir soft`<br/>
5. 上传redis编译后软件包至soft目录下
6. 在soft目录下新建redis-cluster目录<br/>
新建后soft目录结构如下：

		[mbank@h158145 soft]$ ll
		total 62156
		drwxr-xr-x 7 mbank mbank     4096 Dec  1 13:02 redis-4.0.1
		drwxr-xr-x 5 mbank mbank     4096 Dec  1 13:04 redis-cluster
7. 在redis-cluster目录下新建7001 ~ 7003三个目录

		[mbank@h158145 redis-cluster]$ pwd
		/home/mbank/soft/redis-cluster
		[mbank@h158145 redis-cluster]$ ll
		total 12
		drwxr-xr-x 4 mbank mbank 4096 Dec  1 13:03 7001
		drwxr-xr-x 4 mbank mbank 4096 Dec  1 13:03 7002
		drwxr-xr-x 4 mbank mbank 4096 Dec  1 13:03 7003
8. 在7001 ~ 7003目录下分别新建conf 和 logs两个目录

		[mbank@h158145 7001]$ pwd
		/home/mbank/soft/redis-cluster/7001
		[mbank@h158145 7001]$ ll
		total 8
		drwxr-xr-x 2 mbank mbank 4096 Dec  1 13:24 conf
		drwxr-xr-x 2 mbank mbank 4096 Dec  1 13:22 logs
9. 分别上传redis.conf至7001~7003的conf目录下

		[mbank@h158145 conf]$ pwd
		/home/mbank/soft/redis-cluster/7001/conf
		[mbank@h158145 conf]$ ll
		total 64
		-rw-r--r-- 1 mbank mbank 57779 Dec  1 13:03 redis.conf
10. 编辑redis.conf，修改后台驻留支持<br/>
	`vi redis.conf`<br/>

		################################# GENERAL #####################################
		
		# By default Redis does not run as a daemon. Use 'yes' if you need it.
		# Note that Redis will write a pid file in /var/run/redis.pid when daemonized.
		daemonize yes
11. 针对10.20.158.145 7001节点修改bind ip地址配置

		# JUST COMMENT THE FOLLOWING LINE.
		# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		bind 10.20.158.145
12. 针对10.20.158.145 7001节点修改监听端口
		
		# Accept connections on the specified port, default is 6379 (IANA #815344).
		# If port 0 is specified Redis will not listen on a TCP socket.
		port 7001
13. 修改redis-cluster配置使之支持集群部署形式

		# Normal Redis instances can't be part of a Redis Cluster; only nodes that are
		# started as cluster nodes can. In order to start a Redis instance as a
		# cluster node enable the cluster support uncommenting the following:
		#
		# cluster-enabled yes
		cluster-enabled yes
14. 修改集群中node节点配置文件位置
		
		# cluster-config-file nodes-6379.conf
		cluster-config-file /home/mbank/soft/redis-cluster/7001/conf/node.conf
15. 修改7001节点日志路径
		
		loglevel notice
		
		# Specify the log file name. Also the empty string can be used to force
		# Redis to log on the standard output. Note that if you use standard
		# output for logging but daemonize, logs will be sent to /dev/null
		logfile "/home/mbank/soft/redis-cluster/7001/logs/redis.log"
16. 修改7001进程号目录
		
		# Creating a pid file is best effort: if Redis is not able to create it
		# nothing bad happens, the server will start and run normally.
		pidfile /home/mbank/soft/redis-cluster/7001/logs/redis.pid
17. 修改中间磁盘交换文件目录(AOF和dump文件)

		# The working directory.
		#
		# The DB will be written inside this directory, with the filename specified
		# above using the 'dbfilename' configuration directive.
		#
		# The Append Only File will also be created inside this directory.
		#
		# Note that you must specify a directory here, not a file name.
		dir /home/mbank/soft/redis-cluster/7001/


18. 启动7001节点

		[mbank@h158145 soft]$ redis-4.0.1/bin/redis-server ./redis-cluster/7001/conf/redis.conf &
		[1] 9807
		[mbank@h158145 soft]$ 
		[1]+  Done                    redis-4.0.1/bin/redis-server ./redis-cluster/7001/conf/redis.conf
19. 针对7002、7003节点分别复制7001节点配置文件

		[mbank@h158145 redis-cluster]$ cp -r 7001 7002
		[mbank@h158145 redis-cluster]$ ls
		7001  7002
		[mbank@h158145 redis-cluster]$ 
		[mbank@h158145 redis-cluster]$ 
		[mbank@h158145 redis-cluster]$ cp -r 7001 7003
		[mbank@h158145 redis-cluster]$ ll
		total 12
		drwxr-xr-x 4 mbank mbank 4096 Dec  1 13:22 7001
		drwxr-xr-x 4 mbank mbank 4096 Dec  1 14:01 7002
		drwxr-xr-x 4 mbank mbank 4096 Dec  1 14:01 7003
20. 修改7002 7003对应conf/redis.conf文件中7001特征值为7002和7003
21. 针对10.20.158.149,10.20.158.168重复上述动作，直至9个节点全部启动完成
22. 启动后确认redis进程 ps -ef|grep redis确认三台机器上9个节点完全正常启动
23. 创建集群，在145安装redis-gems环境下执行
		
		redis-4.0.1/src/redis-trib.rb create --replicas 2 10.20.158.145:7001 10.20.158.145:7002 10.20.158.145:7003 10.20.158.149:7001 10.20.158.149:7002 10.20.158.149:7003 10.20.158.168:7001 10.20.158.168:7002 10.20.158.168:7003
创建成功后日志如下：

		>>> Creating cluster
		>>> Performing hash slots allocation on 9 nodes...
		Using 3 masters:
		10.20.158.149:7001
		10.20.158.145:7001
		10.20.158.168:7001
		Adding replica 10.20.158.145:7002 to 10.20.158.149:7001
		Adding replica 10.20.158.168:7002 to 10.20.158.149:7001
		Adding replica 10.20.158.149:7002 to 10.20.158.145:7001
		Adding replica 10.20.158.149:7003 to 10.20.158.145:7001
		Adding replica 10.20.158.145:7003 to 10.20.158.168:7001
		Adding replica 10.20.158.168:7003 to 10.20.158.168:7001
		M: 32dd542e992c9e78856a43080ec5f5b51875416e 10.20.158.145:7001
		   slots:5461-10922 (5462 slots) master
		S: 7786f5ea6b8848242d2114b15eb50b4b6b3f731d 10.20.158.145:7002
		   replicates 60f0e08ff1196d193dd1150c08dafb786e900c70
		S: 6a3f8c949b303fd1f35fe9acfca876501329be3e 10.20.158.145:7003
		   replicates b1a7f35ab72966704c3074d99bd91105995f8032
		M: 60f0e08ff1196d193dd1150c08dafb786e900c70 10.20.158.149:7001
		   slots:0-5460 (5461 slots) master
		S: 5cafcde6eb0ebcafb23345349311ecb1f112996d 10.20.158.149:7002
		   replicates 32dd542e992c9e78856a43080ec5f5b51875416e
		S: 77c98e3af5de3d8e982fc6616775c95adafff7a2 10.20.158.149:7003
		   replicates 32dd542e992c9e78856a43080ec5f5b51875416e
		M: b1a7f35ab72966704c3074d99bd91105995f8032 10.20.158.168:7001
		   slots:10923-16383 (5461 slots) master
		S: bb48759c1aa7341686d6fd5dbb252a1a6a027626 10.20.158.168:7002
		   replicates 60f0e08ff1196d193dd1150c08dafb786e900c70
		S: fd5589d2af00e23fba0e0f9532a3604bee57d6e2 10.20.158.168:7003
		   replicates b1a7f35ab72966704c3074d99bd91105995f8032
		Can I set the above configuration? (type 'yes' to accept): yes
		>>> Nodes configuration updated
		>>> Assign a different config epoch to each node
		>>> Sending CLUSTER MEET messages to join the cluster
		Waiting for the cluster to join.........
		>>> Performing Cluster Check (using node 10.20.158.145:7001)
		M: 32dd542e992c9e78856a43080ec5f5b51875416e 10.20.158.145:7001
		   slots:5461-10922 (5462 slots) master
		   2 additional replica(s)
		S: 7786f5ea6b8848242d2114b15eb50b4b6b3f731d 10.20.158.145:7002
		   slots: (0 slots) slave
		   replicates 60f0e08ff1196d193dd1150c08dafb786e900c70
		S: fd5589d2af00e23fba0e0f9532a3604bee57d6e2 10.20.158.168:7003
		   slots: (0 slots) slave
		   replicates b1a7f35ab72966704c3074d99bd91105995f8032
		S: 5cafcde6eb0ebcafb23345349311ecb1f112996d 10.20.158.149:7002
		   slots: (0 slots) slave
		   replicates 32dd542e992c9e78856a43080ec5f5b51875416e
		S: 77c98e3af5de3d8e982fc6616775c95adafff7a2 10.20.158.149:7003
		   slots: (0 slots) slave
		   replicates 32dd542e992c9e78856a43080ec5f5b51875416e
		M: 60f0e08ff1196d193dd1150c08dafb786e900c70 10.20.158.149:7001
		   slots:0-5460 (5461 slots) master
		   2 additional replica(s)
		S: 6a3f8c949b303fd1f35fe9acfca876501329be3e 10.20.158.145:7003
		   slots: (0 slots) slave
		   replicates b1a7f35ab72966704c3074d99bd91105995f8032
		S: bb48759c1aa7341686d6fd5dbb252a1a6a027626 10.20.158.168:7002
		   slots: (0 slots) slave
		   replicates 60f0e08ff1196d193dd1150c08dafb786e900c70
		M: b1a7f35ab72966704c3074d99bd91105995f8032 10.20.158.168:7001
		   slots:10923-16383 (5461 slots) master
		   2 additional replica(s)
		[OK] All nodes agree about slots configuration.

